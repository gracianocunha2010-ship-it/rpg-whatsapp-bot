from app.engine.progression import xp_needed

def test_xp(): assert xp_needed(1)==100 and xp_needed(2)==150
