# RPG WhatsApp Bot

Base organizada para GitHub + Codespaces + Render.

## O que já existe
- Motor de progressão por XP e Rank.
- Classes, elementos e habilidades configuráveis.
- Validação de nível, Rank, Força, energia e fôlego.
- Combate com ataque, esquiva, bloqueio e fuga.
- Cartões de jogador e batalha em texto.
- API FastAPI.
- Endpoint preparado para futura integração com WhatsApp.
- Testes automáticos básicos.

> Esta é uma base V3. A integração real com a API oficial do WhatsApp e o banco de produção ainda precisam ser configurados.

## 1. Colocar no GitHub

1. Crie um repositório vazio no GitHub.
2. Extraia este ZIP no telemóvel/computador.
3. No repositório, escolha **Add file → Upload files**.
4. Envie **o conteúdo desta pasta**, incluindo `app/`, `tests/`, `.github/`, `requirements.txt`, `render.yaml`, `Procfile`, `.gitignore` e `.env.example`.
5. Faça o commit para a branch `main`.

**Não envie o seu `.env` real.** Ele pode conter tokens e palavras-passe.

## 2. Codespaces

No GitHub: **Code → Codespaces → Create codespace on main**.

No terminal:

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

Depois abra a porta 8080 e acesse `/docs` para testar a API.

## 3. Render

Conecte o repositório ao Render. O `render.yaml` já contém o serviço web.

Para produção, substitua SQLite por PostgreSQL. O sistema precisa de uma base persistente para não perder jogadores e progresso.

## Variáveis de ambiente

Copie `.env.example` apenas como referência. No Render/Codespaces, configure os valores como variáveis de ambiente:

- `DATABASE_URL`
- `BOT_OWNER_ID`
- `WHATSAPP_VERIFY_TOKEN`
- `WHATSAPP_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
