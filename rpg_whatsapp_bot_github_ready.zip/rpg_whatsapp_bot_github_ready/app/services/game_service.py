import random
from sqlalchemy.orm import Session
from ..models import Player,Battle
from ..data.game_data import CLASSES,ELEMENTS
from ..engine.progression import add_xp,can_access
from ..engine.validation import validate_skill,validate_training_complete
from ..engine.combat import attack,dodge,block
from ..engine.cards import battle_cards
class GameService:
 def __init__(self,db): self.db=db
 def create_player(self,external_id,name,is_admin=False):
  p=Player(external_id=external_id,name=name,class_name=random.choice(CLASSES),element=random.choice(list(ELEMENTS)),is_admin=is_admin)
  p.training_progress={'learned':[],'tests':0}; p.rank='S' if is_admin else 'E'; p.training_state='free' if is_admin else 'school'
  self.db.add(p);self.db.commit();self.db.refresh(p);return p
 def learn(self,p,topic):
  if topic not in {'attack','dodge','block','skill'}: return '📚 Aula inexistente.'
  d=p.training_progress or {'learned':[],'tests':0}; learned=set(d.get('learned',[])); learned.add(topic); d['learned']=list(learned); p.training_progress=d; self.db.commit()
  if validate_training_complete(p): p.training_state='test'; self.db.commit(); return '🎓 Aulas concluídas. Agora começa o teste final de combate.'
  return f'✅ Você aprendeu: {topic}. Próxima etapa disponível.'
 def training_test(self,p):
  if p.training_state!='test': return '❌ Você ainda não está na etapa de teste.'
  d=p.training_progress or {}; d['tests']=d.get('tests',0)+1; p.training_progress=d
  p.training_state='free'; add_xp(p,100); self.db.commit(); return '🏫 TESTE APROVADO! 🔓 Você está livre para jogar.'
 def start_battle(self,a,b):
  if a.training_state!='free' or b.training_state!='free': raise ValueError('Ambos os jogadores precisam concluir a Escola.')
  ok,msg=can_access(a,'combate')
  if not ok: raise ValueError(msg)
  battle=Battle(player1_id=a.id,player2_id=b.id,turn_player_id=a.id); self.db.add(battle);self.db.commit();self.db.refresh(battle);return battle,battle_cards(a,b)
 def action(self,battle,p,action,target=None,skill_id=None):
  if battle.status!='active': return '❌ Esta luta terminou.'
  if battle.turn_player_id!=p.id:return '❌ Não é o seu turno.'
  if action=='attack':
   r=attack(p,target); text='🎯 ATAQUE ACERTOU' if r['hit'] else '💨 ATAQUE ERROU'
   if r['hit']:
    blocked=(battle.player1_id==target.id and battle.block_active_player1) or (battle.player2_id==target.id and battle.block_active_player2)
    dmg=r['damage']
    if blocked:
     dmg=max(1,round(dmg*.4));
     if battle.player1_id==target.id:battle.block_active_player1=False
     else:battle.block_active_player2=False
     text+='\n🛡️ BLOQUEIO REDUZIU O DANO.'
    target.hp=max(0,target.hp-dmg);text+=f'\n💥 Dano: {dmg}\n❤️ HP restante: {target.hp}/{target.max_hp}'
    if target.hp<=0:
     battle.status='finished';p.wins+=1;target.losses+=1;add_xp(p,100);text+='\n🏆 VITÓRIA!'
   battle.turn_player_id=target.id if battle.status=='active' else battle.turn_player_id
  elif action=='dodge':
   ok,msg=dodge(p);text=('💨 '+msg) if ok else '❌ '+msg
   if ok:battle.turn_player_id=target.id
  elif action=='block':
   ok,msg=block(p);text=('🛡️ '+msg) if ok else '❌ '+msg
   if ok:
    if battle.player1_id==p.id:battle.block_active_player1=True
    else:battle.block_active_player2=True
    battle.turn_player_id=target.id
  elif action=='skill':
   ok,data=validate_skill(p,skill_id)
   if not ok:return f'❌ HABILIDADE BLOQUEADA\nMotivo: {data}'
   p.energy-=data['energy']; p.stamina-=data['stamina']; dmg=max(1,p.strength*2-target.defense); target.hp=max(0,target.hp-dmg);text=f"🔥 {data['name']} EXECUTADA\n💥 Dano: {dmg}\n⚡ Energia restante: {p.energy}/{p.max_energy}"
   if target.hp<=0:battle.status='finished';p.wins+=1;target.losses+=1;add_xp(p,150);text+='\n🏆 VITÓRIA!'
   else:battle.turn_player_id=target.id
  else:return '❌ Ação inválida.'
  self.db.commit();return text
