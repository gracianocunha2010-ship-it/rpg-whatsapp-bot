RANKS={'E':1,'D':10,'C':20,'B':35,'A':50,'S':75}
ELEMENTS={'fogo':'🔥','agua':'💧','vento':'🌪️','terra':'🪨','raio':'⚡','gelo':'❄️','luz':'✨','trevas':'🌑'}
CLASSES=['guerreiro','mago','assassino']
SKILLS={
 'golpe_forte':{'name':'Golpe Forte','level':3,'rank':'E','strength':15,'energy':8,'stamina':0},
 'bola_de_fogo':{'name':'Bola de Fogo','level':5,'rank':'D','strength':0,'energy':20,'stamina':0},
 'corte_relampago':{'name':'Corte Relâmpago','level':10,'rank':'C','strength':25,'energy':25,'stamina':10},
}
AREAS={'escola':{'rank':'E'},'combate':{'rank':'E'},'missoes':{'rank':'E'},'militar':{'rank':'B'},'comando':{'rank':'A'},'alto_comando':{'rank':'S','admin':True},'administradores':{'rank':'S','admin':True}}
