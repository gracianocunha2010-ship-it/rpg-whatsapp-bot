import requests
from ..config import WHATSAPP_ACCESS_TOKEN,WHATSAPP_PHONE_NUMBER_ID
class WhatsAppAdapter:
 def send_text(self,chat_id,text):
  if not WHATSAPP_ACCESS_TOKEN or not WHATSAPP_PHONE_NUMBER_ID: raise RuntimeError('Configure WHATSAPP_ACCESS_TOKEN e WHATSAPP_PHONE_NUMBER_ID.')
  url=f'https://graph.facebook.com/v23.0/{WHATSAPP_PHONE_NUMBER_ID}/messages'
  r=requests.post(url,headers={'Authorization':f'Bearer {WHATSAPP_ACCESS_TOKEN}','Content-Type':'application/json'},json={'messaging_product':'whatsapp','to':chat_id,'type':'text','text':{'body':text}},timeout=20);r.raise_for_status();return r.json()
