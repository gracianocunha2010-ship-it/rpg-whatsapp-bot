from fastapi import FastAPI,Request,HTTPException
from .database import SessionLocal,init_db
from .config import WHATSAPP_VERIFY_TOKEN
from .services.game_service import GameService
from .models import Player
app=FastAPI(title='RPG WhatsApp Bot')
init_db()
@app.get('/')
def root(): return {'status':'online','system':'RPG automatico'}
@app.post('/players')
def create_player(payload:dict):
 db=SessionLocal()
 try:return GameService(db).create_player(payload['external_id'],payload.get('name','Jogador')).__dict__
 finally:db.close()
@app.get('/players/{external_id}')
def player(external_id:str):
 db=SessionLocal()
 try:
  p=db.query(Player).filter_by(external_id=external_id).first()
  if not p: raise HTTPException(404,'Jogador não encontrado')
  return {k:v for k,v in p.__dict__.items() if k!='_sa_instance_state'}
 finally:db.close()
@app.get('/webhook')
def verify_webhook(request:Request):
 q=request.query_params
 if q.get('hub.verify_token')!=WHATSAPP_VERIFY_TOKEN: raise HTTPException(403,'Token inválido')
 return int(q.get('hub.challenge','0'))
@app.post('/webhook')
async def webhook(payload:dict):
 # Parser mínimo: a camada WhatsApp pode ser expandida sem alterar o motor do RPG.
 return {'received':True}
