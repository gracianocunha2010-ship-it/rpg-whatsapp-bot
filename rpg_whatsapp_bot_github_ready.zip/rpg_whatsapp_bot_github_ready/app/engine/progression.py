from ..data.game_data import RANKS
def xp_needed(level): return 100 + (level-1)*50
def add_xp(p, amount):
    p.xp += max(0,amount); levels=0
    while p.xp >= xp_needed(p.level):
        p.xp -= xp_needed(p.level); p.level += 1; levels += 1
        p.max_hp += 10; p.max_energy += 5; p.max_stamina += 5; p.strength += 3; p.defense += 2; p.speed += 2
        p.hp,p.energy,p.stamina=p.max_hp,p.max_energy,p.max_stamina
    promote_rank(p)
    return levels
def promote_rank(p):
    if p.is_admin: p.rank='S'; return False
    old=p.rank; eligible=[r for r,v in RANKS.items() if p.level>=v]
    p.rank=max(eligible,key=lambda r:RANKS[r]); return p.rank!=old
def can_access(p, area):
    from ..data.game_data import AREAS
    rule=AREAS.get(area)
    if not rule: return False,'Área inexistente.'
    if rule.get('admin') and not p.is_admin: return False,'Área exclusiva para administradores.'
    if RANKS[p.rank] < RANKS[rule['rank']]: return False,f"Requer Rank {rule['rank']}. Seu Rank: {p.rank}."
    return True,''
