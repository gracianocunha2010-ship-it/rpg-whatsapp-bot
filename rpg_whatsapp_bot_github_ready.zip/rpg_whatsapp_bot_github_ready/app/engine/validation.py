from ..data.game_data import SKILLS,RANKS
def validate_skill(p, skill_id):
    s=SKILLS.get(skill_id)
    if not s:return False,'Habilidade inexistente.'
    if p.level<s['level']:return False,f"Nível insuficiente. Necessário: {s['level']}. Seu nível: {p.level}."
    if RANKS[p.rank]<RANKS[s['rank']]:return False,f"Rank insuficiente. Necessário: {s['rank']}. Seu Rank: {p.rank}."
    if p.strength<s['strength']:return False,f"Força insuficiente. Necessário: {s['strength']}. Sua Força: {p.strength}."
    if p.energy<s['energy']:return False,f"Energia insuficiente. Necessário: {s['energy']}. Disponível: {p.energy}."
    if p.stamina<s['stamina']:return False,f"Fôlego insuficiente. Necessário: {s['stamina']}. Disponível: {p.stamina}."
    return True,s
def validate_training_complete(p):
    required={'attack','dodge','block','skill'}
    done=set((p.training_progress or {}).get('learned',[]))
    return required.issubset(done)
