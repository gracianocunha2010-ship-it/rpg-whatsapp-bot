from ..data.game_data import ELEMENTS
def player_card(p):
    e=ELEMENTS.get(p.element,p.element)
    return f'''╔════════════════════╗\n       🧾 FICHA\n╚════════════════════╝\n👤 {p.name}\n🏆 Rank: {p.rank} | ⭐ Nível: {p.level}\n🧩 Elemento: {e} {p.element.upper()}\n❤️ HP: {p.hp}/{p.max_hp}\n⚡ Energia: {p.energy}/{p.max_energy}\n💨 Fôlego: {p.stamina}/{p.max_stamina}\n⚔️ Força: {p.strength}\n🛡️ Defesa: {p.defense}\n💨 Velocidade: {p.speed}'''
def battle_cards(a,b):
    return f'''⚔️ BATALHA INICIADA\n\n{player_card(a)}\n\n        VS\n\n{player_card(b)}\n\n🎯 Primeiro turno: {a.name}'''
