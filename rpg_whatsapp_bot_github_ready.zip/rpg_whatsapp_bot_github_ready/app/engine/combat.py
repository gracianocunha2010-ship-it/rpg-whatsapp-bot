import random
def attack(attacker, defender):
    hit=max(55,min(95,70+(attacker.speed-defender.speed)*2))
    if random.randint(1,100)>hit:return {'hit':False,'damage':0}
    damage=max(1,attacker.strength+random.randint(-3,5)-defender.defense//2)
    return {'hit':True,'damage':damage}
def dodge(player):
    cost=20
    if player.stamina<cost:return False,'Fôlego insuficiente.'
    player.stamina-=cost; return True,'Esquiva executada.'
def block(player):
    cost=15
    if player.stamina<cost:return False,'Fôlego insuficiente.'
    player.stamina-=cost; return True,'Bloqueio ativado. O próximo dano será reduzido em 60%.'
