import os
from dotenv import load_dotenv
load_dotenv()
DATABASE_URL=os.getenv('DATABASE_URL','sqlite:///./rpg.db')
BOT_OWNER_ID=os.getenv('BOT_OWNER_ID','admin')
WHATSAPP_VERIFY_TOKEN=os.getenv('WHATSAPP_VERIFY_TOKEN','change-me')
WHATSAPP_ACCESS_TOKEN=os.getenv('WHATSAPP_ACCESS_TOKEN','')
WHATSAPP_PHONE_NUMBER_ID=os.getenv('WHATSAPP_PHONE_NUMBER_ID','')
