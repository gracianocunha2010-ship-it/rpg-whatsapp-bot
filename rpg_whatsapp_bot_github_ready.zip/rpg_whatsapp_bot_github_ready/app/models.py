from sqlalchemy import Column,Integer,String,Boolean,Float,JSON,ForeignKey,DateTime
from datetime import datetime
from .database import Base
class Player(Base):
    __tablename__='players'
    id=Column(Integer,primary_key=True)
    external_id=Column(String(100),unique=True,index=True,nullable=False)
    name=Column(String(100),nullable=False)
    class_name=Column(String(50),nullable=False)
    element=Column(String(50),nullable=False)
    level=Column(Integer,default=1)
    rank=Column(String(5),default='E')
    xp=Column(Integer,default=0)
    hp=Column(Integer,default=100)
    max_hp=Column(Integer,default=100)
    energy=Column(Integer,default=80)
    max_energy=Column(Integer,default=80)
    stamina=Column(Integer,default=100)
    max_stamina=Column(Integer,default=100)
    strength=Column(Integer,default=10)
    defense=Column(Integer,default=10)
    speed=Column(Integer,default=10)
    training_state=Column(String(30),default='school')
    training_progress=Column(JSON,default=dict)
    is_admin=Column(Boolean,default=False)
    wins=Column(Integer,default=0)
    losses=Column(Integer,default=0)
    created_at=Column(DateTime,default=datetime.utcnow)
class Battle(Base):
    __tablename__='battles'
    id=Column(Integer,primary_key=True)
    player1_id=Column(Integer,ForeignKey('players.id'))
    player2_id=Column(Integer,ForeignKey('players.id'))
    turn_player_id=Column(Integer)
    status=Column(String(20),default='active')
    block_active_player1=Column(Boolean,default=False)
    block_active_player2=Column(Boolean,default=False)
    created_at=Column(DateTime,default=datetime.utcnow)
class Mission(Base):
    __tablename__='missions'
    id=Column(Integer,primary_key=True)
    player_id=Column(Integer,ForeignKey('players.id'))
    title=Column(String(120))
    difficulty=Column(String(20))
    reward_xp=Column(Integer,default=0)
    reward_coins=Column(Integer,default=0)
    status=Column(String(20),default='available')
class GameEvent(Base):
    __tablename__='game_events'
    id=Column(Integer,primary_key=True)
    event_type=Column(String(50))
    payload=Column(JSON,default=dict)
    created_at=Column(DateTime,default=datetime.utcnow)
